const { randomUUID } = require('node:crypto');
const suite = require('./wa-suite.cjs');

const peerFromId = id => /^(?:true|false)_([^_]+)_.+/.exec(id || '')?.[1] || '';
const directPeer = peer => /@(c\.us|s\.whatsapp\.net|lid)$/.test(peer);
async function snapshot(page) {
  return page.locator('#main').evaluate(main => ({
    name: main.querySelector('header [title]')?.getAttribute('title') || '',
    messages: Array.from(main.querySelectorAll('.message-in, .message-out')).map(el => ({
      id: el.closest('[data-id]')?.getAttribute('data-id') || '',
      text: Array.from(el.querySelectorAll('.selectable-text.copyable-text, [data-testid="msg-text"], .selectable-text')).at(-1)?.textContent || '',
      direction: el.classList.contains('message-in') ? 'incoming' : 'outgoing',
      status: el.classList.contains('message-in') ? 'Received' :
        el.querySelector('[data-icon="msg-check"],[data-icon="msg-dblcheck"]') ? 'Accepted' : 'Unconfirmed',
    })).filter(m => m.id && m.text),
  }));
}
async function unreadChats(page) {
  return page.locator('#pane-side').evaluate(pane => {
    const selector = pane.querySelector('[role="row"]') ? '[role="row"]' : pane.querySelector('[role="listitem"]') ? '[role="listitem"]' : '.cell-frame-container';
    const rows = Array.from(pane.querySelectorAll(selector));
    const chats = [];
    for (const row of rows) {
      const badge = row.querySelector('[aria-label*="unread" i],[aria-label*="غير مقروء"],[data-testid="icon-unread-count"],[data-testid="unread-count"],[data-icon="unread-count"]');
      const name = row.querySelector('[title]')?.getAttribute('title');
      if (!badge || !name) continue;
      const digits = `${badge.getAttribute('aria-label') || ''} ${badge.textContent || ''}`.replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).match(/\d+/);
      if (!digits || Number(digits[0]) < 1) continue;
      if (!chats.some(c => c.name === name)) chats.push({ name, count: Number(digits[0]), selector });
    }
    return chats;
  });
}

async function filter({ page, job, act, update, guard, restriction }) {
  for (const target of job.targets) {
    await act(`Checking WhatsApp registration for ${target.name}…`, () => page.goto(`https://web.whatsapp.com/send?phone=${target.name.slice(1)}`, { waitUntil: 'domcontentloaded' }));
    const deadline = Date.now() + 30000;
    let status = 'Unknown', reason = 'No definitive platform response. Not classified as inactive.';
    while (Date.now() < deadline) {
      guard(); await restriction();
      if (await page.getByText(/phone number shared via url is invalid|phone number.*is(n't| not) on whatsapp|is not registered on whatsapp|رقم الهاتف.*(غير صحيح|غير صالح|ليس.*واتساب|غير مسجل)/i).first().isVisible().catch(() => false)) {
        status = 'Inactive'; reason = 'WhatsApp explicitly reported an invalid or unregistered number.'; break;
      }
      if (await page.locator('footer [contenteditable="true"][role="textbox"]').first().isVisible().catch(() => false)) {
        status = 'Active/Valid'; reason = 'WhatsApp opened a direct-chat composer. This does not confirm consent or recipient activity.'; break;
      }
      await new Promise(resolve => setTimeout(resolve, 250));
    }
    update((j, state) => {
      const result = state.waSuite.filter.results.find(r => r.id === target.id);
      if (result) Object.assign(result, { status, reason, checkedAt: new Date().toISOString() });
      j.completedCount++; j.currentStep++; j.progress = Math.round(j.completedCount / j.totalCount * 100);
    }, `WaFilter: ${target.name} — ${status}. ${reason}`, status === 'Active/Valid' ? 'success' : 'warning');
    if (status === 'Unknown') throw new Error('Number check was inconclusive. Filter stopped instead of marking remaining numbers inactive; review WhatsApp manually.');
  }
}

async function inbox({ page, job, getState, act, update, guard, restriction, generateReply }) {
  const observed = new Map();
  const tails = new Map();
  // Baseline pre-existing unread history unless the user explicitly approved it.
  const initialUnread = new Set((await unreadChats(page)).map(c => c.name));
  update(j => { j.phase = 'Watching unread inbox'; }, 'Watching the open chat and visible unread direct conversations. Initial unread history is imported without replies. Only opted-in clients and enabled SQLite rules can send. A human composer draft pauses inbox switching.');
  while (true) {
    guard(); await restriction();
    if (!await page.locator('#pane-side').count().catch(() => 0)) {
      update(j => { j.phase = 'Waiting for sign-in / QR'; j.nextActionAt = null; });
      await new Promise(resolve => setTimeout(resolve, 1000));
      continue;
    }
    let openedUnread = null, initial = false;
    const draft = page.locator('footer [contenteditable="true"][role="textbox"],footer [contenteditable="true"][data-tab]').first();
    const humanDraft = await draft.isVisible().catch(() => false) && (await draft.textContent() || '').trim();
    if (!humanDraft) {
      const chats = await unreadChats(page);
      for (const candidate of chats) {
        const rows = page.locator(`#pane-side ${candidate.selector}`)
          .filter({ has: page.locator(`[title=${JSON.stringify(candidate.name)}]`) });
        // Ambiguous names must never route replies to a different person.
        if (await rows.count() === 1) {
          const previous = await snapshot(page).catch(() => null);
          await rows.first().click();
          await page.locator('#main').waitFor({ timeout: 15000 });
          // A changed header alone is insufficient: old bubbles may still be mounted.
          await page.waitForFunction(({ name, previousName, previousPeer }) => {
            const main = document.querySelector('#main');
            if (main?.querySelector('header [title]')?.getAttribute('title') !== name) return false;
            const last = Array.from(main.querySelectorAll('.message-in, .message-out')).at(-1);
            const id = last?.closest('[data-id]')?.getAttribute('data-id') || '';
            const peer = /^(?:true|false)_([^_]+)_.+/.exec(id)?.[1];
            return Boolean(peer && (name === previousName || !previousPeer || peer !== previousPeer));
          }, { name: candidate.name, previousName: previous?.name, previousPeer: peerFromId(previous?.messages.at(-1)?.id) }, { timeout: 15000 });
          openedUnread = candidate;
          initial = initialUnread.delete(candidate.name) && job.replyToExistingUnread !== true;
          break;
        }
      }
    }
    if (!await page.locator('#main').isVisible().catch(() => false)) {
      await new Promise(resolve => setTimeout(resolve, 1000)); continue;
    }
    const current = await snapshot(page).catch(() => null);
    if (!current) { await new Promise(resolve => setTimeout(resolve, 1000)); continue; }
    const peer = peerFromId(current.messages.at(-1)?.id);
    if (!directPeer(peer)) { await new Promise(resolve => setTimeout(resolve, 1000)); continue; }
    const key = `${job.accountId}:${peer}`;
    const stored = getState().waSuite.threads.find(t => t.remoteKey === key);
    const baseline = !observed.has(key), known = observed.get(key) || new Set(stored?.messages.map(m => m.id) || []);
    const fresh = current.messages.filter(m => peerFromId(m.id) === peer && !known.has(m.id));
    if (fresh.length) {
      update((_j, state) => {
        let thread = state.waSuite.threads.find(t => t.remoteKey === key);
        const phone = /@(c\.us|s\.whatsapp\.net)$/.test(peer) ? suite.phone(peer.split('@')[0]) : suite.phone(current.name);
        if (!thread && phone) thread = state.waSuite.threads.find(t => t.phone === phone && !t.remoteKey);
        if (!thread) {
          if (state.waSuite.threads.length >= 1000) throw new Error('CRM is full. Stop monitoring and remove unused clients.');
          thread = { id: randomUUID(), name: (current.name || phone || 'WhatsApp client').slice(0, 150), phone,
            status: 'New', notes: '', optedIn: false, contactId: null, messages: [], updatedAt: new Date().toISOString() };
          state.waSuite.threads.unshift(thread);
          suite.linkContact(state, thread);
        }
        thread.accountId = job.accountId; thread.remoteKey = key;
        const storedIds = new Set(thread.messages.map(m => m.id));
        for (const message of fresh) if (!storedIds.has(message.id)) thread.messages.push({
          ...message, text: message.text.slice(0, 10000), timestamp: new Date().toISOString(),
          status: message.status,
        });
        thread.messages = thread.messages.slice(-200);
        thread.updatedAt = new Date().toISOString();
        // Opt-out takes precedence even when another message in the same batch matches a rule.
        if (fresh.some(m => m.direction === 'incoming' && suite.optOut(m.text))) {
          thread.optedIn = false; suite.linkContact(state, thread);
        }
        _j.phase = 'Watching unread inbox'; _j.nextActionAt = null;
        _j.currentStep = (_j.currentStep || 0) + fresh.length;
      }, `${baseline ? 'Initial history' : 'New messages'} synced for ${current.name || 'client'} (${fresh.length}).`, 'info');
    }
    for (const m of current.messages) known.add(m.id);
    if (known.size > 50000) throw new Error('Session observation limit reached. Review and restart monitoring.');
    observed.set(key, known);
    const previousTail = tails.get(key);
    const tailIndex = current.messages.findIndex(m => m.id === previousTail);
    const unreadIds = new Set(openedUnread && !initial
      ? current.messages.filter(m => m.direction === 'incoming').slice(-openedUnread.count).map(m => m.id) : []);
    const incoming = fresh.filter(m => m.direction === 'incoming' &&
      (unreadIds.has(m.id) || (!baseline && tailIndex >= 0 && current.messages.findIndex(x => x.id === m.id) > tailIndex))).at(-1);
    tails.set(key, current.messages.at(-1)?.id);
    if (incoming && !fresh.some(m => m.direction === 'incoming' && suite.optOut(m.text))) {
      const state = getState(), thread = state.waSuite.threads.find(t => t.remoteKey === key);
      const rules = state.waSuite.rules;
      const eligible = thread?.optedIn && (!thread.contactId || state.store.contacts.find(c => c.id === thread.contactId)?.optedIn);
      let rule = eligible && !thread.replyReservations?.[incoming.id] ? rules.find(r => r.match === 'exact' && suite.matches(r, incoming.text)) || rules.find(r => suite.matches(r, incoming.text)) : null;
      const ai = state.waSuite.ai;
      if (!rule && eligible && !thread.replyReservations?.[incoming.id] && ai?.enabled && generateReply) {
        const lastAI = thread.ruleLastAttempts?.['openai-smart'];
        if (!lastAI || Date.now() - Date.parse(lastAI) >= 60000) {
          update(j => { j.phase = 'Generating optional AI reply'; });
          update((_j, s) => {
            const t = s.waSuite.threads.find(t => t.id === thread.id);
            t.ruleLastAttempts = { ...t.ruleLastAttempts, 'openai-smart': new Date().toISOString() };
          });
          try {
            const template = await generateReply(thread, incoming, ai);
            rule = { id: 'openai-smart', name: 'Optional OpenAI', enabled: true, template, match: 'exact',
              keyword: incoming.text, delayMin: 3, delayMax: 8, cooldownMinutes: 1, aiRevision: ai.revision };
          } catch {
            update(j => { j.phase = 'Watching unread inbox'; }, 'OpenAI reply failed. Nothing sent; keyword rules remain available. Check your key, billing and network.', 'warning');
          }
        }
      }
      const lastAttempt = rule && thread.ruleLastAttempts?.[rule.id];
      if (rule && (rule.id === 'openai-smart' || !lastAttempt || Date.now() - Date.parse(lastAttempt) >= rule.cooldownMinutes * 60000)) {
        const response = rule.template.replace(/\{\{name\}\}/g, thread.name);
        const attemptId = `bot-${randomUUID()}`;
        let attempted = false, count = 0;
        const outgoing = page.locator('.message-out').filter({ hasText: response });
        await act(`Replying with rule “${rule.name}”…`, async () => {
          const latest = getState(), latestThread = latest.waSuite.threads.find(t => t.id === thread.id);
          const currentRule = s => rule.id === 'openai-smart'
            ? (s.waSuite.ai?.enabled && s.waSuite.ai.revision === rule.aiRevision &&
              !s.waSuite.rules.some(r => suite.matches(r, incoming.text)) ? rule : null)
            : s.waSuite.rules.find(r => r.id === rule.id);
          const latestRule = currentRule(latest);
          const beforeSend = await snapshot(page);
          if (peerFromId(beforeSend.messages.at(-1)?.id) !== peer) throw new Error('Watched conversation changed while a reply was waiting. Nothing sent.');
          if (rule.id === 'openai-smart' && beforeSend.messages.filter(m => m.direction === 'incoming').at(-1)?.id !== incoming.id) {
            update(j => { j.phase = 'Watching unread inbox'; }, 'Newer incoming message arrived while AI was generating. Stale AI reply suppressed.', 'warning');
            return;
          }
          if (beforeSend.messages.some(m => !known.has(m.id) && m.direction === 'incoming' && suite.optOut(m.text))) {
            update((j, s) => { const t = s.waSuite.threads.find(t => t.id === thread.id); t.optedIn = false; suite.linkContact(s, t); j.phase = 'Watching open conversation'; }, 'Opt-out received while waiting; reply suppressed.', 'warning');
            return;
          }
          if (!latestThread?.optedIn || (latestThread.contactId && !latest.store.contacts.find(c => c.id === latestThread.contactId)?.optedIn) ||
            !latestRule?.enabled || latestRule.template !== rule.template || !suite.matches(latestRule, incoming.text)) {
            update(j => { j.phase = 'Watching open conversation'; }, 'Consent or rule changed while waiting; reply suppressed.', 'warning'); return;
          }
          const input = page.locator('footer [contenteditable="true"][role="textbox"],footer [contenteditable="true"][data-tab]').first();
          if ((await input.textContent() || '').trim()) {
            update(j => { j.phase = 'Watching open conversation'; }, 'A human-written draft is in the composer. Auto-reply suppressed so the draft is not overwritten.', 'warning'); return;
          }
          // Reserve a durable attempt BEFORE touching Send. Ambiguous failures never auto-retry.
          update((_j, s) => {
            const t = s.waSuite.threads.find(t => t.id === thread.id);
            if (Object.keys(t.replyReservations || {}).length >= 50000) throw new Error('Reply reservation limit reached. Stop monitoring and review this client record.');
            t.replyReservations = { ...t.replyReservations, [incoming.id]: attemptId };
            t.ruleLastAttempts = { ...t.ruleLastAttempts, [rule.id]: new Date().toISOString() };
            t.messages.push({
              id: attemptId, text: response, direction: 'outgoing', status: 'Unconfirmed', timestamp: new Date().toISOString(), ruleId: rule.id,
            });
          });
          count = await outgoing.count();
          await input.fill(response);
          await restriction();
          const finalState = getState(), finalThread = finalState.waSuite.threads.find(t => t.id === thread.id);
          const finalRule = currentRule(finalState);
          const finalSnapshot = await snapshot(page);
          if (peerFromId(finalSnapshot.messages.at(-1)?.id) !== peer) throw new Error('Conversation changed before Send. Reply not submitted; inspect the browser draft.');
          if (!finalThread?.optedIn || !finalRule?.enabled || finalRule.template !== rule.template ||
            (finalThread.contactId && !finalState.store.contacts.find(c => c.id === finalThread.contactId)?.optedIn)) throw new Error('Consent or rule changed before Send. Reply not submitted; inspect the browser draft.');
          await page.locator('button:has([data-icon="send"]), [role="button"]:has([data-icon="send"])').first().click();
          attempted = true;
        }, { min: rule.delayMin, max: rule.delayMax });
        if (attempted) {
          await outgoing.nth(count).waitFor({ timeout: 30000 });
          await outgoing.nth(count).locator('[data-icon="msg-check"], [data-icon="msg-dblcheck"]').first().waitFor({ timeout: 30000 });
          await restriction();
          const confirmedId = await outgoing.nth(count).evaluate(el => el.closest('[data-id]')?.getAttribute('data-id'));
          if (confirmedId) known.add(confirmedId);
          update((j, s) => {
            const t = s.waSuite.threads.find(t => t.id === thread.id), reply = t.messages.find(m => m.id === attemptId);
            reply.status = 'Accepted'; if (confirmedId) reply.id = confirmedId;
            t.messages = t.messages.slice(-200); t.updatedAt = new Date().toISOString();
            s.analytics.realMessagesSent = (s.analytics.realMessagesSent || 0) + 1;
            j.completedCount++; j.phase = 'Watching open conversation'; j.nextActionAt = null;
          }, `WhatsApp accepted the auto-reply from “${rule.name}”. Recipient delivery is not guaranteed.`, 'success');
        }
      }
    }
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
}
module.exports = { filter, inbox, peerFromId, directPeer, snapshot, unreadChats };
